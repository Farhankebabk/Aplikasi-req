# MoneyRecap Android

Aplikasi Android offline yang membungkus UI MoneyRecap dalam Android WebView. UI, tema midnight, transaksi, edit/hapus, filter, laporan bulanan, CSV, Excel-compatible `.xls`, dan backup JSON berasal dari file HTML lokal yang disertakan. Data transaksi disimpan di localStorage WebView pada penyimpanan aplikasi; tidak ada server dan tidak ada izin internet.

## Membuat APK

1. Pasang Android Studio versi stabil dan Android SDK Platform 36.
2. Ekstrak ZIP ini.
3. Android Studio → Open → pilih folder `MoneyRecapAndroid`.
4. Tunggu Gradle Sync selesai.
5. Pilih Build → Build Bundle(s) / APK(s) → Build APK(s).
6. APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

Alternatif terminal dari folder proyek (dengan Gradle terpasang): `gradle assembleDebug`.

## Fitur Android khusus

- File ekspor membuka pemilih lokasi penyimpanan Android (Storage Access Framework).
- Cetak/PDF menggunakan dialog cetak Android; pilih “Save as PDF”.
- Semua aset HTML disertakan di aplikasi, jadi UI dapat dibuka tanpa internet.

## Catatan data

Data disimpan dalam localStorage WebView milik aplikasi. Data akan bertahan saat aplikasi ditutup, tetapi dapat hilang jika aplikasi dihapus atau data aplikasi dibersihkan. Gunakan menu Data & Backup untuk mengunduh backup JSON berkala. Ini bukan sinkronisasi cloud.

## Catatan build

Project membutuhkan koneksi internet satu kali untuk Android Studio mengunduh Gradle/Android Gradle Plugin dan platform SDK bila belum tersedia. Setelah dipasang, aplikasi berjalan offline.

## Ikon aplikasi
Ikon launcher MoneyRecap dikonfigurasi melalui `app/src/main/AndroidManifest.xml`, dengan resource adaptive icon di `app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml`. Latar ikon berada di `values/colors.xml` dan gambar foreground berbasis vector drawable di `drawable/ic_launcher_foreground.xml`.


## Backup restore on Android

The Android WebView implements `WebChromeClient.onShowFileChooser` so the Restore Backup button can open the system document picker. Select the JSON backup file in Downloads or the folder where it was saved. The app validates each transaction and reports a specific error if the selected JSON is not compatible.
