# Midnight Ledger Android

Proyek Android untuk aplikasi **Midnight Ledger**. Aplikasi menampilkan antarmuka HTML lokal melalui Android WebView, menyimpan transaksi di penyimpanan lokal aplikasi, dan mendukung ekspor file serta cetak laporan/PDF.

## Cara membuat APK tanpa laptop (menggunakan HP)

Proyek ini belum berupa APK siap instal; ini adalah kode sumber Android. Kamu bisa membangun APK melalui GitHub Actions dari browser HP:

1. Unduh dan ekstrak ZIP proyek ini di HP.
2. Masuk ke GitHub melalui browser dan buat repository baru, misalnya `MidnightLedgerAndroid`.
3. Unggah seluruh isi folder `MidnightLedgerAndroid` ke repository. Pastikan folder `.github/workflows` ikut terunggah.
4. Buka tab **Actions** pada repository. Jika diminta, aktifkan Actions untuk repository tersebut.
5. Pilih workflow **Build Android APK**, lalu tekan **Run workflow**. Jika workflow belum terlihat, pastikan file `.github/workflows/build-apk.yml` sudah masuk ke branch `main` atau `master`.
6. Tunggu sampai workflow selesai dengan status hijau.
7. Buka hasil run workflow, cari bagian **Artifacts**, lalu unduh `MidnightLedger-debug-apk`.
8. Ekstrak ZIP artifact. Di dalamnya ada `app-debug.apk`. Buka file tersebut untuk menginstal aplikasi. Android mungkin meminta izin **Install unknown apps** untuk browser atau aplikasi file manager yang digunakan.

> APK debug cocok untuk pengujian dan instalasi pribadi. Untuk publikasi ke Play Store, aplikasi perlu proses signing/release dan persiapan tambahan.

## Cara membangun lewat Android Studio

1. Buka folder proyek ini di Android Studio.
2. Pastikan Android SDK Platform 36 tersedia.
3. Tunggu Gradle Sync selesai.
4. Pilih **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Fitur dan penyimpanan data

- Antarmuka aplikasi disimpan secara lokal di `app/src/main/assets/index.html`.
- Data transaksi disimpan di `localStorage` milik WebView aplikasi.
- Ekspor file menggunakan pemilih lokasi penyimpanan Android.
- Cetak laporan menggunakan dialog cetak Android; pilih **Save as PDF** untuk menyimpan PDF.
- Tidak memerlukan koneksi internet saat digunakan, setelah aplikasi berhasil dibuat dan diinstal.

Data lokal dapat hilang jika aplikasi dihapus atau data aplikasi dibersihkan. Gunakan fitur backup JSON secara berkala.
