package com.midnightledger.android;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int CREATE_FILE_REQUEST = 4101;
    private static final int PICK_RESTORE_FILE_REQUEST = 4102;
    private static final int PICK_SOUND_REQUEST = 4103;
    private WebView webView;
    private byte[] pendingBytes;
    private ValueCallback<Uri[]> restoreFileCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11, 20, 25));
        getWindow().setNavigationBarColor(Color.rgb(11, 20, 25));

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] {Manifest.permission.POST_NOTIFICATIONS}, 0);
        }

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(11, 20, 25));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.getSettings().setSupportZoom(false);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams) {
                // WebView tidak membuka <input type="file"> kecuali callback ini ada.
                if (restoreFileCallback != null) restoreFileCallback.onReceiveValue(null);
                restoreFileCallback = filePathCallback;
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.putExtra(Intent.EXTRA_MIME_TYPES,
                            new String[] {"application/json", "text/json", "text/plain", "application/octet-stream"});
                    startActivityForResult(intent, PICK_RESTORE_FILE_REQUEST);
                } catch (Exception e) {
                    restoreFileCallback.onReceiveValue(null);
                    restoreFileCallback = null;
                    Toast.makeText(MainActivity.this,
                            "Tidak dapat membuka pemilih file. Coba lagi atau gunakan pengelola file lain.",
                            Toast.LENGTH_LONG).show();
                }
                return true;
            }
        });
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidLedger");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void saveTextFile(String name, String mime, String content) {
            byte[] bytes = (content == null ? "" : content).getBytes(StandardCharsets.UTF_8);
            runOnUiThread(() -> {
                try {
                    pendingBytes = bytes;
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
                    intent.putExtra(Intent.EXTRA_TITLE, name == null || name.isEmpty() ? "moneyrecap-export" : name);
                    startActivityForResult(intent, CREATE_FILE_REQUEST);
                } catch (Exception e) {
                    pendingBytes = null;
                    Toast.makeText(MainActivity.this, "Tidak dapat membuka lokasi penyimpanan", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void printReport() {
            runOnUiThread(() -> {
                try {
                    PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                    if (printManager == null) {
                        Toast.makeText(MainActivity.this, "Fitur cetak tidak tersedia di perangkat ini", Toast.LENGTH_LONG).show();
                        return;
                    }
                    String jobName = "MoneyRecap - Laporan Keuangan";
                    printManager.print(jobName, webView.createPrintDocumentAdapter(jobName),
                            new PrintAttributes.Builder()
                                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                    .setResolution(new PrintAttributes.Resolution("pdf", "PDF", 300, 300))
                                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                    .build());
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Gagal membuka pencetakan PDF", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void syncTasks(String json) {
            Reminders.sync(MainActivity.this, json);
        }

        @JavascriptInterface
        public int reminderInterval() {
            return Reminders.intervalMinutes(MainActivity.this);
        }

        @JavascriptInterface
        public void setReminderInterval(int minutes) {
            Reminders.setIntervalMinutes(MainActivity.this, minutes);
        }

        @JavascriptInterface
        public String reminderSound() {
            return Reminders.soundTitle(MainActivity.this);
        }

        @JavascriptInterface
        public boolean dndGranted() {
            return getSystemService(NotificationManager.class).isNotificationPolicyAccessGranted();
        }

        @JavascriptInterface
        public void pickSound() {
            runOnUiThread(() -> {
                Intent intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
                intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE,
                        RingtoneManager.TYPE_ALARM | RingtoneManager.TYPE_NOTIFICATION);
                intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false);
                intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Reminders.soundUri(MainActivity.this));
                startActivityForResult(intent, PICK_SOUND_REQUEST);
            });
        }

        @JavascriptInterface
        public void openDndSettings() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshReminderSettings(); // status izin DND bisa berubah di pengaturan sistem
    }

    private void refreshReminderSettings() {
        webView.evaluateJavascript("window.refreshReminder&&refreshReminder()", null);
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_RESTORE_FILE_REQUEST) {
            ValueCallback<Uri[]> callback = restoreFileCallback;
            restoreFileCallback = null;
            if (callback != null) {
                Uri selected = (resultCode == RESULT_OK && data != null) ? data.getData() : null;
                callback.onReceiveValue(selected == null ? null : new Uri[] {selected});
            }
        } else if (requestCode == PICK_SOUND_REQUEST) {
            if (resultCode == RESULT_OK && data != null) {
                Uri picked = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
                if (picked != null) Reminders.setSound(this, picked);
                refreshReminderSettings();
            }
        } else if (requestCode == CREATE_FILE_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new IllegalStateException("Output stream unavailable");
                    out.write(pendingBytes);
                    Toast.makeText(this, "File berhasil disimpan", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Gagal menyimpan file", Toast.LENGTH_LONG).show();
                }
            }
            pendingBytes = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (restoreFileCallback != null) restoreFileCallback.onReceiveValue(null);
        webView.removeJavascriptInterface("AndroidLedger");
        webView.destroy();
        super.onDestroy();
    }
}
