package com.midnightledger.android;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.hasExtra("id")) Reminders.fire(context, intent.getLongExtra("id", 0));
        else Reminders.scheduleAll(context); // boot atau app diperbarui: alarm hilang, pasang ulang
    }
}
