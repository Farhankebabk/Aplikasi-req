package com.midnightledger.android;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Daftar tugas dicerminkan dari JS ke SharedPreferences supaya alarm tetap jalan saat app tertutup. */
final class Reminders {
    private Reminders() {}

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("reminders", Context.MODE_PRIVATE);
    }

    static int intervalMinutes(Context c) {
        return prefs(c).getInt("interval", 30);
    }

    static void setIntervalMinutes(Context c, int minutes) {
        prefs(c).edit().putInt("interval", Math.max(1, minutes)).apply();
        scheduleAll(c);
    }

    static Uri soundUri(Context c) {
        String s = prefs(c).getString("sound", null);
        return s != null ? Uri.parse(s) : RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
    }

    static void setSound(Context c, Uri uri) {
        prefs(c).edit().putString("sound", uri.toString()).apply();
    }

    static String soundTitle(Context c) {
        Ringtone r = RingtoneManager.getRingtone(c, soundUri(c));
        return r == null ? "Default" : r.getTitle(c);
    }

    static void sync(Context c, String json) {
        try {
            new JSONArray(json); // tolak data rusak sebelum mengubah apa pun
        } catch (JSONException e) {
            Log.e("Reminders", "Daftar tugas tidak valid", e);
            return;
        }
        JSONArray old = tasks(c);
        for (int i = 0; i < old.length(); i++) {
            JSONObject t = old.optJSONObject(i);
            if (t != null) c.getSystemService(AlarmManager.class).cancel(pending(c, t.optLong("id")));
        }
        prefs(c).edit().putString("tasks", json).apply();
        scheduleAll(c);
    }

    static void scheduleAll(Context c) {
        JSONArray a = tasks(c);
        for (int i = 0; i < a.length(); i++) {
            JSONObject t = a.optJSONObject(i);
            if (t != null) schedule(c, t.optLong("id"), t.optLong("deadline"));
        }
    }

    /** Dipanggil saat alarm berbunyi: tampilkan notifikasi lalu jadwalkan pengulangan berikutnya. */
    static void fire(Context c, long id) {
        JSONArray a = tasks(c);
        for (int i = 0; i < a.length(); i++) {
            JSONObject t = a.optJSONObject(i);
            if (t != null && t.optLong("id") == id) {
                notifyTask(c, id, t.optString("title"));
                schedule(c, id, t.optLong("deadline"));
                return;
            }
        }
    }

    private static JSONArray tasks(Context c) {
        try {
            return new JSONArray(prefs(c).getString("tasks", "[]"));
        } catch (JSONException e) {
            return new JSONArray();
        }
    }

    private static PendingIntent pending(Context c, long id) {
        Intent i = new Intent(c, ReminderReceiver.class).putExtra("id", id).setData(Uri.parse("task://" + id));
        return PendingIntent.getBroadcast(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    // Pertama bunyi tepat di tenggat, sesudahnya tiap interval. Bila tenggat sudah lewat, ambil slot berikutnya.
    private static void schedule(Context c, long id, long deadline) {
        long step = intervalMinutes(c) * 60_000L, now = System.currentTimeMillis();
        long at = deadline > now ? deadline : deadline + ((now - deadline) / step + 1) * step;
        AlarmManager am = c.getSystemService(AlarmManager.class);
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(c, id));
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(c, id));
        }
    }

    private static void notifyTask(Context c, long id, String title) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        Intent open = new Intent(c, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent tap = PendingIntent.getActivity(c, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        nm.notify(Long.hashCode(id), new Notification.Builder(c, channelId(c, nm))
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setColor(0xFF00594F)
                .setContentTitle("Tugas lewat tenggat")
                .setContentText("Kerjakan sekarang: " + title)
                .setCategory(Notification.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(tap)
                .build());
    }

    // Suara channel tidak bisa diubah setelah dibuat, jadi tiap nada punya channel sendiri.
    private static String channelId(Context c, NotificationManager nm) {
        Uri sound = soundUri(c);
        String id = "task_" + Integer.toHexString(sound.toString().hashCode());
        if (nm.getNotificationChannel(id) == null) {
            for (NotificationChannel old : nm.getNotificationChannels()) {
                if (old.getId().startsWith("task_")) nm.deleteNotificationChannel(old.getId());
            }
            NotificationChannel ch = new NotificationChannel(id, "Pengingat tugas", NotificationManager.IMPORTANCE_HIGH);
            ch.setBypassDnd(true);
            ch.enableVibration(true);
            ch.setSound(sound, new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build());
            nm.createNotificationChannel(ch);
        }
        return id;
    }
}
