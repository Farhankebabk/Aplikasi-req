plugins {
    id("com.android.application")
}

android {
    namespace = "com.midnightledger.android"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.midnightledger.android"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
