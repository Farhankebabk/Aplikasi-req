# MoneyRecap Android

Aplikasi keuangan pribadi offline. UI ada di `app/src/main/assets/index.html`, dibungkus WebView oleh `MainActivity`. Data disimpan di localStorage WebView; tidak ada server dan tidak ada izin internet.

## Build APK

1. Pasang Android Studio dan Android SDK Platform 36.
2. Buka folder `MidnightLedgerAndroid`, tunggu Gradle Sync selesai.
3. Build → Build APK(s). Hasilnya di `app/build/outputs/apk/debug/app-debug.apk`.

Gradle butuh internet satu kali untuk mengunduh plugin dan SDK. Setelah itu aplikasi berjalan offline.

## Fitur

- Transaksi (tambah, edit, hapus, urungkan), filter, laporan bulanan.
- Ekspor CSV dan `.xls`, cetak/PDF lewat dialog cetak Android, backup/restore JSON (termasuk daftar tugas).
- Dua area dengan navigasi bawah: Keuangan dan Tugas. Di area Tugas, pengguna mengisi nama tugas dan tenggat. Begitu tenggat lewat, notifikasi berbunyi berulang sampai tugas ditandai selesai atau dihapus.

## Pengingat tugas

- Interval ulang (15 menit, 30 menit, 1 jam, 3 jam) dan nada dering dipilih di area Tugas, bagian Pengingat.
- Notifikasi memakai alarm sistem dan channel dengan `bypassDnd`. Agar tembus mode DND, tekan **Izin DND** lalu aktifkan akses untuk MoneyRecap. Mode "Total silence" tetap membungkam semua aplikasi.
- Mengetuk notifikasi membuka area Tugas.
- Alarm dipasang ulang otomatis setelah perangkat restart atau aplikasi diperbarui.
- Pada Android 13+ aplikasi meminta izin notifikasi saat pertama dibuka.

## Catatan data

Data hilang bila aplikasi dihapus atau datanya dibersihkan. Unduh backup JSON secara berkala dari tab Data & Backup. Saat restore, backup lama tanpa tugas akan menghapus daftar tugas yang ada.
